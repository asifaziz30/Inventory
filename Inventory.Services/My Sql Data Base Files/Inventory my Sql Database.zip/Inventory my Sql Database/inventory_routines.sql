-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: inventory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'inventory'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item`(
pName varchar(200),
pCode varchar(10),
pVendorId INT

)
BEGIN

	SELECT * FROM item
    WHERE 
    (pName=Name OR pName='' OR pName is null) AND
    (pCode=Code OR pCode='' OR pCode is null) AND
        StatusId <> 5 ;
	
     

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_item_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item_by_id`(pId tinyint)
BEGIN
	SELECT *
    FROM Item
    WHERE Id =pId LIMIT 1; 
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_item_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item_create`(
pName VARCHAR(200),
pQuantity VARCHAR(10),
pPrice decimal(18,2),
pDescription VARCHAR(250),
pStatusId INT,
pCreatedBy INT,
pCreatedOn DATETIME
)
BEGIN

	INSERT INTO item(NAME, Description,Quantity,Price, CreatedBy, CreatedOn,StatusId)
	VALUES(pNAME,  pDescription, pQuantity,pPrice, pCreatedBy, pCreatedOn,pStatusId);
	
	SELECT 1;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_item_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item_delete`(
pId INT,
pStatusId tinyint,
pUserName VARCHAR(200),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN

	UPDATE item
    SET StatusId=pStatusId, 
        UserName=pUserName, 
        UpdatedBy=pUpdatedBy, 
        UpdatedOn=pUpdatedOn
        WHERE Id=pId;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_item_paging` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item_paging`(
pName varchar(200),
pageSize INT,
pSkip INT,
orderByColumn VARCHAR(10),
orderBy varchar(15)
)
BEGIN

	SELECT * FROM item
    WHERE 
    (pName=Name OR pName='' OR pName is null) AND
    
    
     StatusId <> 5 
	order by orderByColumn ,orderBy LIMIT  pSkip, pageSize;
     
     
       SELECT COUNT(1) Total FROM item
        WHERE 
    (pName=Name OR pName='' OR pName is null) AND
    
     
     StatusId <> 5 ;
	
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_item_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_item_update`(
pId INT,
pName VARCHAR(200),
pQuantity VARCHAR(10),
pPrice decimal(18,2),
pDescription VARCHAR(250),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN

	UPDATE item
    SET NAME=pNAME, 
		Description=pDescription,
        Quantity=pQuantity, 
        Price=pPrice,
        UpdatedBy=pUpdatedBy, 
        UpdatedOn=pUpdatedOn
        WHERE Id=pId;
	
    select 1;
    
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order`(
pVendorId INT,
pPurchaseOrderNumber VARCHAR(20),
pStartDate DATE,
pEndDate DATE,
pageSize INT,
pSkip INT,
orderByColumn VARCHAR(10),
orderBy VARCHAR(5)
)
BEGIN
	SET @StartDate = CONCAT(pStartDate , ' 00:00:00');
	SET @EndDate = CONCAT(pEndDate , ' 23:59:59');
        
    SET @sqlQuery = concat("SELECT p.*
		FROM purchase_order p 
		WHERE 
        (p.CreatedBy = ",pVendorId," OR ",pVendorId,"= 0) AND
		(p.PurchaseOrderNumber = '", pPurchaseOrderNumber, "' OR '", pPurchaseOrderNumber, "'='') AND
        p.StatusId <> 5 AND
		p.PurchaseOrderDate BETWEEN '", @StartDate, "' AND '", @EndDate , "' 
        order by p.Id desc LIMIT  ",pSkip,", ",pageSize,"
        ");
       --   order by p.",orderByColumn," ",orderBy," LIMIT  ",pSkip,", ",pageSize,"
    --   select @sqlQuery;
    
		PREPARE stmt3 FROM @sqlQuery;
		EXECUTE stmt3;
		DEALLOCATE PREPARE stmt3;
        
        SELECT COUNT(1) Total 
		FROM purchase_order
		WHERE 
        (CreatedBy = pVendorId OR  pVendorId = 0) AND
        (PurchaseOrderNumber = pPurchaseOrderNumber OR pPurchaseOrderNumber ='') AND
         StatusId <>5 AND
		PurchaseOrderDate BETWEEN @StartDate AND @EndDate;
        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_all_item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_all_item`(
pPurchaseOrderId INT
)
BEGIN

	select * FROM purchase_order_item
    WHERE  PurchaseOrderId=pPurchaseOrderId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_by_id`(pId tinyint)
BEGIN
	SELECT *
    FROM purchase_order
    WHERE Id =pId LIMIT 1; 
    
    SELECT * FROM purchase_order_item
    WHERE PurchaseOrderId=pId;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_create`(
pPurchaseOrderDate DATE,
pItems LONGTEXT,          
pStatusId TINYINT,
pUserName VARCHAR(20),
pCreatedBy INT,
pCreatedOn DATETIME
)
BEGIN

	-- DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	-- START TRANSACTION;
    
	INSERT INTO purchase_order(PurchaseOrderDate, StatusId, UserName,  CreatedBy, CreatedOn)
	VALUES(pPurchaseOrderDate,  pStatusId, pUserName,pCreatedBy, pCreatedOn);
	
    SET @Id = LAST_INSERT_ID();
    
    
    INSERT INTO purchase_order_item(PurchaseOrderId, ItemId, Name, Quantity, Price)
    SELECT @Id, ItemId, Name, Quantity, Price
    FROM JSON_TABLE(pItems, "$[*]" COLUMNS (
                         ItemId INT PATH "$.ItemId",
                         Name VARCHAR(150)  PATH "$.Name",
                         Quantity INT  PATH "$.Quantity",
                         Price FLOAT PATH "$.Price"
						 )
			  ) AS tt;
    
    
    UPDATE purchase_order
    SET PurchaseOrderNumber= CONCAT('PO#', DATE_FORMAT(UTC_DATE, '%Y%m%d'), @Id),
    TotalItems = (Select COUNT(1) FROM purchase_order_item WHERE PurchaseOrderId=@Id)
    WHERE Id=@Id;
    
    /*
    UPDATE Item itm
    INNER JOIN 
    JSON_TABLE(pItems, "$[*]" COLUMNS (
                         ItemId BIGINT PATH "$.ItemId",
                         Name VARCHAR(150)  PATH "$.Name",
                         Quantity INT  PATH "$.Quantity",
                         Price FLOAT PATH "$.Price"
						 )
			  ) AS tt
    ON itm.Id=tt.ItemId
    SET itm.Quantity=itm.Quantity + tt.Quantity;
    */
    
	SELECT CONCAT('PO#', DATE_FORMAT(UTC_DATE, '%Y%m%d'), @Id);
    
    -- COMMIT;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_delete`(
pId INT,
pStatusId TINYINT,
pUserName VARCHAR(20),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN
  
	UPDATE purchase_order 
    SET StatusId=pStatusId,
		UserName=pUserName,
        UpdatedBy=pUpdatedBy,
        UpdatedOn=pUpdatedOn
    WHERE Id=pId;
        
	SELECT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_item`(
pPurchaseOrderId INT,
pageSize INT,
pSkip INT,
orderByColumn VARCHAR(10),
orderBy varchar(15)
)
BEGIN

	select * FROM purchase_order_item
    WHERE  PurchaseOrderId=pPurchaseOrderId
     order by orderByColumn ,orderBy LIMIT  pSkip, pageSize;
     
	select count(1)  Total FROM purchase_order_item
    WHERE  PurchaseOrderId=pPurchaseOrderId
	order by orderByColumn ,orderBy LIMIT  pSkip, pageSize;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_item_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_item_delete`(
pId INT,
pPurchaseOrderId INT
)
BEGIN

	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION;
    
	DELETE FROM purchase_order_item
    WHERE ItemId=pId AND PurchaseOrderId=pPurchaseOrderId;
    
    UPDATE purchase_order
    SET TotalItems=TotalItems-1,
    StatusId=CASE WHEN TotalItems-1=0 THEN 5 ELSE StatusId END
    WHERE Id=pPurchaseOrderId;
    
	SELECT 1;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_list`(

pStartDate DATE,
pEndDate DATE

)
BEGIN
	SET @StartDate = CONCAT(pStartDate , ' 00:00:00');
	SET @EndDate = CONCAT(pEndDate , ' 23:59:59');
        
    SELECT Count(1) As Count,p.purchaseorderdate
		FROM purchase_order p 
		WHERE 
       p.StatusId <> 5 AND
       p.StatusId <> 19 AND
		p.PurchaseOrderDate BETWEEN  @StartDate  AND  @EndDate  group by p.purchaseorderdate ;
      
        
       
        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_receive` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_receive`(
pId INT,
pStatusId TINYINT,
pUserName VARCHAR(20),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN

/*	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION; */

	UPDATE Item itm
    INNER JOIN 
    purchase_order_item AS tt
    ON itm.Id=tt.ItemId
    SET itm.Quantity=itm.Quantity + tt.Quantity
    WHERE tt.PurchaseOrderId=pId;
    
	UPDATE purchase_order 
    SET StatusId=pStatusId,
		UserName=pUserName,
        UpdatedBy=pUpdatedBy,
        UpdatedOn=pUpdatedOn
    WHERE Id=pId;
        
	SELECT 1;
    
   -- COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_purchase_order_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_purchase_order_update`(
pId BIGINT,
pPurchaseOrderDate DATE,
pItems LONGTEXT,          
pStatusId TINYINT,
pUserName VARCHAR(20),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION;
    
IF EXISTS(SELECT 1 FROM purchase_order WHERE Id=pId AND StatusId IN (2, 20)) THEN
BEGIN

	
    
    /*
    UPDATE Item itm
    INNER JOIN 
    purchase_order_item AS tt
    ON itm.Id=tt.ItemId
    SET itm.Quantity=itm.Quantity - tt.Quantity
    WHERE tt.PurchaseOrderId=pId;
	*/
    
    DELETE FROM purchase_order_item
    WHERE PurchaseOrderId=pId;
    
    INSERT INTO purchase_order_item(PurchaseOrderId, ItemId, Name, Quantity, Price)
    SELECT pId, ItemId, Name, Quantity, Price
    FROM JSON_TABLE(pItems, "$[*]" COLUMNS (
						 ItemId INT PATH "$.ItemId",
                         Name VARCHAR(150)  PATH "$.Name",
                         Quantity INT  PATH "$.Quantity",
                         Price FLOAT PATH "$.Price"
						 )
			  ) AS tt;
   
   UPDATE purchase_order
    SET PurchaseOrderDate=pPurchaseOrderDate,
    ExpectedDeliveryDate=pExpectedDeliveryDate, 
    ReferenceNumberInternal=pReferenceNumberInternal,
    ReferenceNumberExternal=pReferenceNumberExternal, 
    TotalItems = (Select COUNT(1) FROM purchase_order_item WHERE PurchaseOrderId=pId),
    StatusId=pStatusId, 
    UserName=pUserName,  
    UpdatedBy=pUpdatedBy, 
    UpdatedOn=pUpdatedOn
    WHERE Id=pId;
    
    
	SELECT 1;
END;
ELSE
BEGIN
	SELECT -1;
END;
END IF;
COMMIT;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order`(
pSaleOrderNumber VARCHAR(20),
pStartDate DATE,
pEndDate DATE,
pageSize INT,
pSkip INT,
orderByColumn VARCHAR(10),
orderBy VARCHAR(5)
)
BEGIN
	SET @StartDate = CONCAT(pStartDate , ' 00:00:00');
	SET @EndDate = CONCAT(pEndDate , ' 23:59:59');
        
    SET @sqlQuery = concat("SELECT p.*
		FROM sale_order p 
		WHERE 
		(p.SaleOrderNumber = '", pSaleOrderNumber, "' OR '", pSaleOrderNumber, "'='') AND
        p.StatusId <> 5 AND
		p.SaleOrderDate BETWEEN '", @StartDate, "' AND '", @EndDate , "' 
        order by p.Id desc LIMIT  ",pSkip,", ",pageSize,"
        ");
             --   order by p.",orderByColumn," ",orderBy," LIMIT  ",pSkip,", ",pageSize,"
       -- select @sqlQuery;
    
		PREPARE stmt3 FROM @sqlQuery;
		EXECUTE stmt3;
		DEALLOCATE PREPARE stmt3;
        
        SELECT COUNT(1) Total 
		FROM sale_order
		WHERE 
        
        (saleOrderNumber = pSaleOrderNumber OR pSaleOrderNumber ='') AND
         StatusId <>5 AND
		saleOrderDate BETWEEN @StartDate AND @EndDate;
        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_by_id`(pId tinyint)
BEGIN
	SELECT *
    FROM sale_order
    WHERE Id =pId AND  StatusId<>5 LIMIT 1; 
    
    SELECT * FROM sale_order_item
    WHERE saleOrderId=pId ;
    
    
  
     
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_create` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_create`(
pSaleOrderDate DATE,
pItems LONGTEXT,          
pStatusId TINYINT,
pUserName VARCHAR(20),
pCreatedBy INT,
pCreatedOn DATETIME
)
BEGIN


 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION;
  
	


	INSERT INTO sale_order(saleOrderDate, StatusId, CreatedBy, CreatedOn)
	VALUES(pSaleOrderDate, pStatusId,  pCreatedBy, pCreatedOn);
	
    SET @Id = LAST_INSERT_ID();
    
    
    INSERT INTO sale_order_item(SaleOrderId, ItemId, Name, Quantity, Price )
    SELECT @Id, ItemId, Name, Quantity, Price
    FROM JSON_TABLE(pItems, "$[*]" COLUMNS (
                         ItemId INT PATH "$.ItemId",
                         Name VARCHAR(150)  PATH "$.Name",
                         Quantity INT  PATH "$.Quantity",
                         Price FLOAT PATH "$.Price"
                        
						 )
			  ) AS tt;
    
    UPDATE sale_order
    SET saleOrderNumber= CONCAT('SO#', DATE_FORMAT(UTC_DATE, '%Y%m%d'), @Id),
    TotalItems = (Select COUNT(1) FROM sale_order_item WHERE SaleOrderId=@Id)
    WHERE Id=@Id;
    
    UPDATE Item itm
    INNER JOIN 
    sale_order_item AS tt
    ON itm.Id=tt.ItemId
    SET itm.Quantity=itm.Quantity - tt.Quantity
    WHERE tt.SaleOrderId=@Id;
	SELECT CONCAT('SO#', DATE_FORMAT(UTC_DATE, '%Y%m%d'), @Id);
    
     COMMIT;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_delete`(
pId INT,
pStatusId TINYINT,
pUserName VARCHAR(20),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN
 
	UPDATE sale_order 
    SET StatusId=pStatusId,
		-- UserName=pUserName,
        UpdatedBy=pUpdatedBy,
        UpdatedOn=pUpdatedOn
    WHERE Id=pId;
        
	SELECT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_item` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_item`(
pSaleOrderId INT

)
BEGIN

	select * FROM sale_order_item
    WHERE  saleOrderId=pSaleOrderId;
     
     
	select count(1)  Total FROM sale_order_item
    WHERE  saleOrderId=pSaleOrderId;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_item_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_item_delete`(
pId INT,
pSaleOrderId INT
)
BEGIN
	
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION;
    
	DELETE FROM sale_order_item
    WHERE ItemId=pId AND saleOrderId=pSaleOrderId;
    
    UPDATE sale_order
    SET TotalItems=TotalItems-1,
    StatusId=CASE WHEN TotalItems-1=0 THEN 5 ELSE StatusId END
    WHERE Id=pSaleOrderId;
    
    
	SELECT 1;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_list`(
pSaleOrderNumber VARCHAR(20),
pStartDate DATE,
pEndDate DATE

)
BEGIN
SET @StartDate = CONCAT(pStartDate , ' 00:00:00');
	SET @EndDate = CONCAT(pEndDate , ' 23:59:59');
SELECT * FROM (
select SaleOrderDate as OrderDate,count(1) as TotalAmount,StatusId  From sale_order where 	SaleOrderDate BETWEEN  @StartDate AND  @EndDate AND StatusId in (21,22) group by SaleOrderDate,StatusId
 union all
select PurchaseOrderDate as OrderDate ,count(1) as TotalAmount,StatusId  From purchase_order where PurchaseOrderDate BETWEEN  @StartDate AND  @EndDate AND  StatusId=19 group by OrderDate,StatusId
) V
order by v.OrderDate;

        
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_sale_order_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_sale_order_update`(
pId BIGINT,
pSaleOrderDate DATE,
pCustomerId INT,
pName VARCHAR(200),
pMobile VARCHAR(20),
pTelePhone VARCHAR(20),
pFax VARCHAR(20),
pEmail VARCHAR(120),
pCountryId SMALLINT,
pCountry VARCHAR(100),
pDestinationId INT,
pDestinationCode VARCHAR(10),
pAddress VARCHAR(250),
pTown VARCHAR(20),
pItems LONGTEXT,          
pStatusId TINYINT,
pUserName VARCHAR(20),
pUpdatedBy INT,
pUpdatedOn DATETIME
)
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
          SELECT 0;
          ROLLBACK;
    END;
    
	START TRANSACTION;
  
  
IF EXISTS(SELECT 1 FROM sale_order WHERE Id=pId AND StatusId IN (2, 20)) THEN
BEGIN

	IF pCustomerId =0 THEN
    BEGIN
		
        INSERT INTO Customer(NAME, Mobile, TelePhone, Fax, Email,  CountryId, Country, 
		DestinationId, DestinationCode, Address, Town, StatusId, CreatedBy, CreatedOn)
		VALUES(pNAME, pMobile, pTelePhone, pFax, pEmail, pCountryId, pCountry, 
		pDestinationId, pDestinationCode, pAddress, pTown, pStatusId,  pCreatedBy, pCreatedOn);
        
        SET @CustomerId = LAST_INSERT_ID();
        
    END;
    ELSE
    BEGIN
		        SET @CustomerId = pCustomerId;
    END;
    END IF;

	
    DELETE FROM sale_order_item
    WHERE saleOrderId=pId;
    
    INSERT INTO sale_order_item(saleOrderId, ItemId, Name, Quantity,Weight, Price, SKU,DeliveryServiceId,DeliveryServiceName)
    SELECT pId, ItemId, Name, Quantity,Weight, Price, SKU,DeliveryServiceId,DeliveryServiceName
    FROM JSON_TABLE(pItems, "$[*]" COLUMNS (
						 ItemId INT PATH "$.ItemId",
                         Name VARCHAR(150)  PATH "$.Name",
                         Quantity INT  PATH "$.Quantity",
                          Weight varchar(20) PATH "$.Weight",
                         Price FLOAT PATH "$.Price",
                         SKU varchar(20) PATH "$.SKU",
                        
                         DeliveryServiceId INT PATH "$.DeliveryServiceId",
                         DeliveryServiceName varchar(45) PATH "$.DeliveryServiceName"
						 )
			  ) AS tt;
   
    UPDATE sale_order
    SET saleOrderDate=pSaleOrderDate,
    CustomerId=@CustomerId,
    NAME=pNAME, 
	Mobile=pMobile,
	TelePhone=pTelePhone, 
	Fax=pFax,
	Email=pEmail, 
	CountryId=pCountryId, 
	Country=pCountry, 
	DestinationId = pDestinationId,
	DestinationCode=pDestinationCode,
	Address=pAddress, 
	Town=pTown,
    TotalItems = (Select COUNT(1) FROM sale_order_item WHERE SaleOrderId=pId),
    StatusId=pStatusId, 
    UserName=pUserName,  
    UpdatedBy=pUpdatedBy, 
    UpdatedOn=pUpdatedOn
    WHERE Id=pId;
   
	SELECT 1;
END;
ELSE
BEGIN
	SELECT -1;
END;
END IF;

 COMMIT;
End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-04  3:33:38
