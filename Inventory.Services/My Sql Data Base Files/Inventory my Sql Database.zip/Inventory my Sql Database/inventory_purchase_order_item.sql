-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: inventory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchase_order_item`
--

DROP TABLE IF EXISTS `purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_item` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `PurchaseOrderId` bigint NOT NULL,
  `ItemId` int NOT NULL,
  `Name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quantity` int NOT NULL,
  `Price` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_item`
--

LOCK TABLES `purchase_order_item` WRITE;
/*!40000 ALTER TABLE `purchase_order_item` DISABLE KEYS */;
INSERT INTO `purchase_order_item` VALUES (67,19,12,'IPhone 14 Pro Max',2,5500.00),(68,19,13,'LG',1,1500.00),(70,20,12,'IPhone 14 Pro Max',10,450000.00),(71,21,12,'IPhone 14 Pro Max',15,335000.00),(75,23,12,'IPhone 14 Pro Max',10,450000.00),(76,23,17,'qeqwe',5,5555.56),(78,24,12,'IPhone 14 Pro Max',10,450000.00),(79,25,12,'IPhone 14 Pro Max',12,450000.00),(80,22,13,'LG',1,1500.00),(81,22,12,'IPhone 14 Pro Max',1,450000.00),(82,26,12,'IPhone 14 Pro Max',10,450000.00),(83,27,12,'IPhone 14 Pro Max',10,450000.00),(84,28,12,'IPhone 14 Pro Max',10,450000.00),(85,29,12,'IPhone 14 Pro Max',10,450000.00),(86,30,12,'IPhone 14 Pro Max',23,450000.00),(88,31,13,'LG',4,1500.00),(89,31,12,'IPhone 14 Pro Max',1,450000.00),(91,32,12,'IPhone 14 Pro Max',20,450000.00),(92,33,12,'IPhone 14 Pro Max',10,450000.00),(93,34,12,'IPhone 14 Pro Max',10,450000.00),(94,35,12,'IPhone 14 Pro Max',10,450000.00),(95,36,12,'IPhone 14 Pro Max',10,1000.00),(96,37,12,'IPhone 14 Pro Max',45,450000.00),(97,38,12,'IPhone 14 Pro Max',100,450000.00),(98,39,12,'IPhone 14 Pro Max',10,450000.00),(99,40,12,'IPhone 14 Pro Max',100,450000.00),(100,41,22,'Samsung A10',100,24234.00),(102,49,23,'Apple C4',100,1212.00),(103,57,12,'IPhone 14 Pro Max',10,450000.00),(104,58,12,'IPhone 14 Pro Max',10,450000.00),(105,59,24,'Samsung galaxy Edge',100,10.00),(106,60,12,'IPhone 14 Pro Max',3,450000.00),(107,61,12,'IPhone 14 Pro Max',10,450000.00),(108,62,12,'IPhone 14 Pro Max',10,450000.00),(109,63,12,'IPhone 14 Pro Max',10,450000.00),(110,64,7,'Samsung A10',10,50000.00),(111,65,7,'Samsung A10',10,50000.00),(112,66,7,'Samsung A10',10,50000.00),(113,67,7,'Samsung A10',10,50000.00),(114,68,7,'Samsung A10',10,50000.00),(115,69,7,'Samsung A10',10,50000.00),(116,70,7,'Samsung A10',10,50000.00);
/*!40000 ALTER TABLE `purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-04  3:33:37
