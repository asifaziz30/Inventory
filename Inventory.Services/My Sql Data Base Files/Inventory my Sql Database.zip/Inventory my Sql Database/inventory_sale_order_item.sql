-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: inventory
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sale_order_item`
--

DROP TABLE IF EXISTS `sale_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_order_item` (
  `Id` bigint NOT NULL AUTO_INCREMENT,
  `SaleOrderId` bigint NOT NULL,
  `ItemId` int NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Quantity` int NOT NULL,
  `Price` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_order_item`
--

LOCK TABLES `sale_order_item` WRITE;
/*!40000 ALTER TABLE `sale_order_item` DISABLE KEYS */;
INSERT INTO `sale_order_item` VALUES (98,38,12,'IPhone 14 Pro Max',1,4500.00),(99,38,13,'LG',1,1500.00),(102,39,12,'IPhone 14 Pro Max',10,450000.00),(103,40,12,'IPhone 14 Pro Max',10,450000.00),(104,41,12,'IPhone 14 Pro Max',10,450000.00),(105,42,12,'IPhone 14 Pro Max',10,450000.00),(106,43,12,'IPhone 14 Pro Max',10,450000.00),(107,44,12,'IPhone 14 Pro Max',10,450000.00),(108,45,12,'IPhone 14 Pro Max',10,450000.00),(109,46,12,'IPhone 14 Pro Max',10,450000.00),(111,48,12,'IPhone 14 Pro Max',10,450000.00),(112,49,12,'IPhone 14 Pro Max',10,450000.00),(113,12,12,'IPhone 14 Pro Max',10,450000.00),(114,52,12,'IPhone 14 Pro Max',10,450000.00),(115,52,12,'IPhone 14 Pro Max',10,450000.00),(116,52,12,'IPhone 14 Pro Max',13,450000.00),(117,53,12,'IPhone 14 Pro Max',10,450000.00),(118,53,13,'LG',20,1500.00),(120,54,12,'IPhone 14 Pro Max',2,450000.00),(121,54,13,'LG',10,1500.00),(123,55,12,'IPhone 14 Pro Max',5,450000.00),(124,56,12,'IPhone 14 Pro Max',3,450000.00),(125,57,12,'IPhone 14 Pro Max',29,450000.00),(126,58,12,'IPhone 14 Pro Max',10,450000.00),(127,59,12,'IPhone 14 Pro Max',10,450000.00),(128,60,12,'IPhone 14 Pro Max',10,450000.00),(129,61,12,'IPhone 14 Pro Max',10,450000.00),(130,62,12,'IPhone 14 Pro Max',10,450000.00),(131,63,12,'IPhone 14 Pro Max',10,450000.00),(132,64,12,'IPhone 14 Pro Max',10,450000.00),(133,65,12,'IPhone 14 Pro Max',5,450000.00),(134,65,17,'qeqwe',5,5555.56),(136,66,12,'IPhone 14 Pro Max',50,450000.00),(137,67,12,'IPhone 14 Pro Max',0,450000.00),(138,67,17,'qeqwe',0,5555.56),(140,68,12,'IPhone 14 Pro Max',0,450000.00),(141,69,22,'Samsung A10',10,24234.00),(148,72,12,'IPhone 14 Pro Max',0,450000.00),(149,72,22,'Samsung A10',0,24234.00),(151,73,12,'IPhone 14 Pro Max',0,450000.00),(152,73,22,'Samsung A10',0,24234.00),(154,74,12,'IPhone 14 Pro Max',0,450000.00),(155,76,12,'IPhone 14 Pro Max',0,450000.00),(156,77,12,'IPhone 14 Pro Max',0,450000.00),(157,78,12,'IPhone 14 Pro Max',0,450000.00),(158,79,12,'IPhone 14 Pro Max',0,450000.00),(159,80,12,'IPhone 14 Pro Max',0,450000.00),(160,81,12,'IPhone 14 Pro Max',0,450000.00),(161,82,12,'IPhone 14 Pro Max',0,450001.00),(162,83,12,'IPhone 14 Pro Max',0,450000.00),(163,84,12,'IPhone 14 Pro Max',1,450000.00),(165,86,12,'IPhone 14 Pro Max',10,450000.00),(166,86,22,'Samsung A10',0,24234.00),(168,87,12,'IPhone 14 Pro Max',10,450000.00),(169,88,12,'IPhone 14 Pro Max',1,450000.00),(170,88,22,'Samsung A10',0,24234.00),(172,89,12,'IPhone 14 Pro Max',1,450000.00),(173,89,22,'Samsung A10',0,24234.00),(175,90,12,'IPhone 14 Pro Max',1,450000.00),(176,90,22,'Samsung A10',0,24234.00),(178,91,12,'IPhone 14 Pro Max',1,450000.00),(179,91,22,'Samsung A10',0,24234.00),(181,92,12,'IPhone 14 Pro Max',10,450000.00),(182,92,22,'Samsung A10',10,24234.00),(184,93,12,'IPhone 14 Pro Max',10,450000.00),(185,93,22,'Samsung A10',0,24234.00),(187,94,12,'IPhone 14 Pro Max',2,450000.00),(188,95,22,'Samsung A10',0,24234.00),(189,96,12,'IPhone 14 Pro Max',10,450000.00),(190,96,22,'Samsung A10',10,24234.00),(192,97,12,'IPhone 14 Pro Max',10,450000.00),(193,97,22,'Samsung A10',10,24234.00),(195,98,12,'IPhone 14 Pro Max',-1,450000.00),(196,98,22,'Samsung A10',1,24234.00),(198,107,12,'IPhone 14 Pro Max',1,450000.00),(199,108,12,'IPhone 14 Pro Max',10,450000.00),(200,109,12,'IPhone 14 Pro Max',10,450000.00),(201,110,12,'IPhone 14 Pro Max',10,450000.00),(202,111,12,'IPhone 14 Pro Max',10,450000.00),(203,111,22,'Samsung A10',10,24234.00),(205,112,12,'IPhone 14 Pro Max',1,450000.00),(206,120,7,'Samsung A10',10,50000.00),(207,121,12,'IPhone 14 Pro Max',2,450000.00),(208,122,7,'Samsung A10',20,50000.00),(209,123,7,'Samsung A10',20,50000.00),(210,124,12,'IPhone 14 Pro Max',10,450000.00);
/*!40000 ALTER TABLE `sale_order_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-04  3:33:37
